# react-project

## subin

## ramram

## sumin

# 뚜니들의 프로젝트

## library

npm i -g apollo
npm i @apollo/client

npm i react-hook-form

npm install react-phone-number-input

## axios - api 통신

## react-query - Component에서의 state 관리 (react hook)

-api
npm i axios
npm i js-cookie
npm i @tanstack/react-query
npm i @tanstack/react-query-devtools
