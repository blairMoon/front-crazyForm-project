import React from 'react';

const Introduce = () => {
  return <div>Introduce</div>;
};

export default Introduce;
