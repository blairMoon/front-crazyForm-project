import React from 'react';

const SearchData = () => {
  return <div>SearchData</div>;
};

export default SearchData;
